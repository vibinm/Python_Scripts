items = ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
print(enumerate(items))

for index, item in enumerate('peter'):
    print(index, item)
