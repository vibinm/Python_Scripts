tiny = [2.2, 0.98, 3.4, 1.2, 2.3]

print(tiny + tiny)
print()
print(tiny * 3)