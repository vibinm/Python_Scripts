"""demo for the print"""

print('kim', end='\t')  # keyword arguments, Output Record Sep ORS
print('jim', end='\t')
print('tim', end='\t')
print('tom')
print(1,2,'iii',4,5)
print(1,2,'iii',4,5, sep=':'), # Output Field sep