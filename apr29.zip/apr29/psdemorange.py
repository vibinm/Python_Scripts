for item in range(10):
    print(item)
