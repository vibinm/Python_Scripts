import shutil

shutil.copy('passwd.txt', 'passwd.db')

# shutil.rmtree('/tmp/catch22')