info = {}

print(info)
print(type(info))
print(len(info))