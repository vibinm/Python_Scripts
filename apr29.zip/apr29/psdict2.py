info = {
    'host': 'ws1',
    'domain': 'rootcap.in',
    'desc': 'web server',
    'app': 'apache httpd',
    'version': 2.2
}

print(info)
print(type(info))
print(len(info))

# add
# update
# delete
# lookup aka read
# iterate
