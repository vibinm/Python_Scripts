"""delete by index"""
items = [2.2, 'pam', .98, 3.4, 1.2, 'jim', 'nick', 'neil', 'sam', 2.3, 'pat', 'norton']
value = items.pop()

print(value)
print(items)
print()

items = [2.2, 'pam', .98, 3.4, 1.2, 'jim', 'nick', 'neil', 'sam', 2.3, 'pat', 'norton']
value = items.pop(0)

print(value)
print(items)
print()
