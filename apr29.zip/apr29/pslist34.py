items = [1, 2.2, 'pam', 3, 4, 1, 2.2, 'pam', 3, 4, 1, 2.2, 'pam', 3, 4]

print(set(items))
uniq = list(set(items))
print(uniq)