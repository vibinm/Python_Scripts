
keys = ['pwd', 'uid', 'gid', 'gecos', 'home', 'shell']
values = ['x', '173', '173', 'abrt', '/etc/abrt', '/sbin/nologin']


# print(zip(keys, values))
# print()
# print(list(zip(keys, values)))
# print()
print(dict(zip(keys, values)))