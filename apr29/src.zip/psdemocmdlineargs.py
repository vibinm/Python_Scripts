"""command line args"""

import sys

print(sys.argv)
