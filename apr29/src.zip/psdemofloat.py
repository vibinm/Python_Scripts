
print(0.003)
print(3e-3)
print(3E-3)
print()

n = 4+3j
print(n)
print(type(n))
print(n.real)
print(n.imag)
print(n.conjugate())
print(n.conjugate() * n)