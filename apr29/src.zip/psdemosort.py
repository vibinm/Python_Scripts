items = [2.2, 0.98, 3.4, 1.2, 2.3, 2.2, 0.98, 3.4, 1.2, 2.3, 2.2, 0.98, 3.4, 1.2, 2.3]

items.sort()  # inplace edit
print(items)
print()

items.sort(reverse=True)  # inplace edit
print(items)
print()

items = [2.2, 0.98, 3.4, 1.2, 2.3, 2.2, 0.98, 3.4, 1.2, 2.3, 2.2, 0.98, 3.4, 1.2, 2.3]
items.reverse() # inplace edit
print(items)