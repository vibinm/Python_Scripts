s = 'python'  # immutable object

print(s)
print(id(s))
s = 123
print(s)
print(id(s))