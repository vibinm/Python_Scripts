file_path = 'c:\templates\rules\blames\folder99\neon\temp.txt'
print(file_path)
print()

file_path = r'c:\templates\rules\blames\folder99\neon\temp.txt'  # raw string
print(file_path)
print()