name = 'danske'
city = 'bangalore'

print('name :', name)
print('city :', city)
