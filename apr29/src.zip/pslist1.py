items = []
print(items)
print(len(items))
print(type(items))