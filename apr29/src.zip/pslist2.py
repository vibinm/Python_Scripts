items = [2.2, 'pam', .98, 3.4, 1.2, 'jim', 'nick', 'neil', 'sam', 2.3, 'pat', 'norton']
print(items)
print()

items[-2] = 'patric' # update
print(items)
print()

items.append('danske')
print(items)
print()

items.insert(0, 'bangalore')  # prepend
print(items)
print()
