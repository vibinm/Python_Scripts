name = 'pam', 'sam', 'tim', 'tom'
print(name)
print()

n = (1000)
print(n)
print()

n = (1000,)
print(n)
print(len(n))
print()

print(divmod(8, 5))