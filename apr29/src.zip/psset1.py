items = set()
print(items)
print(type(items))
print(len(items))