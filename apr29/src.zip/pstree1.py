i = 1

while i <= 5:
    j = 1
    while j <= i:
        print(j, end='\t')
        j += 1
    i += 1
    print()
