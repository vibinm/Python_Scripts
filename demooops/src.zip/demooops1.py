class SystemInformation:
    pass


si = SystemInformation()
print(si)
print(SystemInformation)
print(__name__)