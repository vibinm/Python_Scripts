"""
syntax for the lambda :-

    lambda arg1, arg2,....: expression
"""

power = lambda x, n: x ** n
print(power)
print(power(3, 4))
