import requests
from pprint import pprint as pp
import urllib.parse as parse
print(parse.quote('^'))


# uri = 'https://reqres.in/api/users/7'
#
#
#
# response = requests.get(uri)
# print(response.status_code)
# print()
# pp(response.json())
