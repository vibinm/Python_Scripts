import psutil
from pprint import pprint as pp

print(psutil.virtual_memory())
print()
print(psutil.swap_memory())
