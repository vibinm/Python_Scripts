import telnetlib
telnetlib.test()
