#!/bin/bash

w
echo
echo
free -m
echo
echo
df -h